global start
#on_start("toy(\"txt_editor\")")

#print("test".upper())

#quit()
global path_current
global mode

if re.search(r".*\.py$", path_current):
    try:
        with open(path_current + "/" + user_command + ".py") as file:
            exec(file.read())
            print(print_string)
    except FileNotFoundError:
        if os.path.exists(path_current + "/" + user_command):
            path_current += "/" + user_command
        else:
            print("\n" + get_color_escape(red) + "ERROR CODE: 2\n " + get_color_escape(yellow) + "FILE NOT LOCATED: " + path_current + "/" + user_command + ".py")
            input(get_color_escape(green) + "PRESS ENTER TO PROCEED\n")

print_string = clear_screen() + Cursor.POS()
print(print_string)
print_string += plAIground_logo() + "\n" + get_color_escape(yellow) + "TOYBOX:" + toybox_name + "\n"
#if toybox == "CLI":
print_string += get_color_escape(orange) + "\n➽  COMMANDS:" + get_color_escape(green) + "\n ➷  start/" + get_color_escape(yellow) + "\n   ➼  GUI\n   ➼  CLI" + get_color_escape(green) + "\n ➸  exit" + get_color_escape(yellow) + " - " + get_color_escape(green) + "Stops plAIground" + "\n ➸  restart" + get_color_escape(yellow) + " - " + get_color_escape(orange) + "NOT WORKING" + get_color_escape(green) + "\n ➸  /"
print(print_string)
for i in range(len(toy_list)):
    try:
        with open(main_path + "/" + toy_list[i] + ".py") as toy:
            #print(toy.read())
            #quit()
            exec(toy.read())
            #print(print_string)
            #print(toy.readlines())
            #print(main_path + "/" + toy_list[i] + ".py")
            #time.sleep(5)
            #quit()
    except FileNotFoundError:
        print("\n" + get_color_escape(red) + "ERROR CODE: 2\n " + get_color_escape(yellow) + "FILE NOT LOCATED: " + main_path + "/" + toy_list[i] + ".py")
        input(get_color_escape(green) + "PRESS ENTER TO PROCEED\n")
#print(print_string)
path_display = ""
#path_alternating = 0
for i in path_current.split("/"):
    path_display += str(get_color_escape(blue) + i)
    if i != path_current.split("/")[-1]:
        path_display += str(get_color_escape(dark_blue) + "/")
    else:
        path_display += str(get_color_escape(dark_blue))
#print(abspath(getsourcefile(lambda:0)))
user_command = input("\n" + path_display + ">" + get_color_escape(yellow_greeny))

if re.search("^exit", user_command):
    print(RESET)
    quit()
elif re.search("^restart", user_command):
    print(get_color_escape(red), "Restarting..")
    print(RESET)
    raise Exception("REQUESTED RESTART")
elif re.search("^/", user_command):
    #if user_command == "/":
        #path_current = del(path_current)
    if os.path.exists(path_current + user_command):
        path_current += user_command
    else:
        print(get_color_escape(red) + "ERROR CODE: 2\n " + get_color_escape(yellow) + "FILE NOT LOCATED: " + get_color_escape(orange) + path_current + user_command)
        input(get_color_escape(green) + "PRESS ENTER TO PROCEED\n")
elif user_command == "-" or user_command == "":
    new_path_list = path_current.split("/")
    path_current = ""
    del new_path_list[-1]
    for i in range(len(new_path_list)):
        path_current += "/" + new_path_list[i]
    path_current = reverse(reverse(path_current).strip("/"))
else:
    #with open(path_current + "/" + user_command) as file:
    #    exec(file.read())
    try:
        with open(path_current + "/" + user_command + ".py") as file:
            exec(file.read())
            print(print_string)
    except FileNotFoundError:
        if os.path.exists(path_current + "/" + user_command):
            path_current += "/" + user_command
        else:
            print("\n" + get_color_escape(red) + "ERROR CODE: 2\n " + get_color_escape(yellow) + "FILE NOT LOCATED: " + path_current + "/" + user_command + ".py")
            input(get_color_escape(green) + "PRESS ENTER TO PROCEED\n")
    #except Exception:
    #    print("UNEXCPECTED ERROR")
    #    input("PRESS ENTER TO PROCEED\n")