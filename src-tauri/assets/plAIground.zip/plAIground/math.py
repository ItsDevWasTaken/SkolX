ran = random.randint
us_lang = input("LANGUANGE: ")
difficulty = input("DIFFICULTY: ")
while True:
    def pluralize_substrings(text):
        pattern = r'(\d+)\s+(\w+)'
        def replacement(match):
            count = int(match.group(1))
            word = match.group(2)
            if count != 1:
                if word.endswith('s'):
                    return f"{count} {word}es"
                else:
                    return f"{count} {word}s"
            else:
                return f"{count} {word}"
        return re.sub(pattern, replacement, text)
    def word(type):
        with open(path_current + "/math_files/" + type + ".txt", "r") as file:
            nonstriped_words = file.readlines()#.strip("\n")#.split("\n")
            striped_words = []
            for i in nonstriped_words:
                striped_words.append(i.strip("\n"))
        result = striped_words[ran(0,len(striped_words)-1)]
        #print(result)
        return result
    
    def question():
        with open(path_current + "/math_files/math_questions_" + difficulty + ".txt", "r") as file:
            nonstriped_lines = file.readlines()#.strip("\n")#.split("\n")
            striped_qlines = []
            line_start = (ran(1,int(len(nonstriped_lines)/6))-1)*6
            for i in range(1,6):
                striped_qlines.append(nonstriped_lines[line_start + (i - 1)].strip("\n"))
        result = striped_qlines
        #print(result)
        return result
    
    all_word_types = ["nouns", "verbs", "first_names", "middle_names", "last_names", "place_names", "other_names"]
    
    numbers = []
    nouns = []
    verbs = []
    first_names = []
    middle_names = []
    last_names = []
    place_names = []
    other_names = []
    for i in range(100):
        for thing_type in all_word_types:
            included = True
            while included:
                rword = word(thing_type)
                if rword in str(eval(thing_type)):
                    included = True
                else:
                    exec(f"{thing_type}.append(rword)")
                    break
        
        #number = ran(0,100)
        #if number != 1:
        #    rword += "s"
         #= {word("noun"): str(ran(0,100))}

    #print(list(nouns.keys())[0])
    #print(list(nouns.values())[0])
    
    q = question()

    #print(q[0].format(last_names=last_names))
    #print(q[0].format(numbers=numbers, nouns=nouns, verbs=verbs, first_names=first_names, middle_names=middle_names, last_names=last_names, other_names=other_names, place_names=place_names))
    #user_confirmation()
    print(q)
    def ran_num():
        for i in q[0].split("|"):
            numbers.append(-9999999999)
            exec(i)
    ran_num()
    ans = eval(q[3].format(numbers=numbers, nouns=nouns, verbs=verbs, first_names=first_names, middle_names=middle_names, last_names=last_names, other_names=other_names, place_names=place_names))
    math_question = pluralize_substrings(q[1].format(numbers=numbers, nouns=nouns, verbs=verbs, first_names=first_names, middle_names=middle_names, last_names=last_names, other_names=other_names, place_names=place_names, ans=str(ans)))
    print_string = math_question + "\n" + q[2].format(numbers=numbers, nouns=nouns, verbs=verbs, first_names=first_names, middle_names=middle_names, last_names=last_names, other_names=other_names, place_names=place_names, ans=str(ans))
    translation = translator.translate(print_string, dest=us_lang)
    print_string = clear_screen() + Cursor.POS() + translation.text + "\n"
    user = input(print_string)
    print_string_old = print_string
    print_string_old += user
    if int(user) == int(ans):
        #print(q)
        print_string = q[4].format(numbers=numbers, nouns=nouns, verbs=verbs, first_names=first_names, middle_names=middle_names, last_names=last_names, other_names=other_names, place_names=place_names, ans=str(ans))
    else:
        print_string = f"Hmm.. that wasn't completely correct. The real answer was: {str(ans)}"
    translation = translator.translate(print_string, dest=us_lang)
    print_string = translation.text
    print(print_string_old + "\n" + print_string)
    user_confirmation()