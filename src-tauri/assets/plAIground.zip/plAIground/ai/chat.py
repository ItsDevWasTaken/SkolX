llm = Llama(
      model_path = main_path + "/ai/models/Meta-Llama-3-8B.Q8_0.gguf",
      # n_gpu_layers=-1, # Uncomment to use GPU acceleration
      # seed=1337, # Uncomment to set a specific seed
      n_ctx=2048, # Uncomment to increase the context window
)

def on_token_generated(token):
    print(token, end='', flush=True)
    # Process the token or store it in a variable as needed

output = ""
ai_response = ""
user_input = ""
print_string_old = ""
history = [";:[CHAT DESCRIPTION]:;\n;:{This is a chat software were [AI] is an AI assistant. The [AI] tries to respond to [USER]'s queries as best a possible and cannot interact with the real world outside of the chat. [AI] can use theese commands:\n /run(<CODE HERE>) - This commands allows the [AI] to execute Python code. EXAMPLE: /run(print('Hellow World'))\nHere is their chat}:;\n;:[CHAT]:;\n\n"] #Here is a list of commands the assistant can execute:\n /run py[code]  - executes Python code<|end|>\n"]

#Use the /python command to print "Hi!"

#while True:

#for token in llm.generate("<|user|>\nWhat is the purpose of AI?<|end|>\n<|assistant|>", stream=True, callback=on_token_generated):
#    output += token
async def ai():
    global print_string
    global print_string_old
    global history
    global ai_response
    history.append(";:[AI]:;\n;:{")
    response = llm("".join(history), max_tokens=4000, stop=[";:[", ";:[CHAT DESCRIPTION]:;",";:[AI]:;",";:[USER]:;",";:[CHAT]:;"], echo=False, stream=True)
    for event in response:
        event_text = event['choices'][0]['text']
        ai_response += event_text
        print_string = print_string_old + get_color_escape(yellow) + "USER> " + get_color_escape(yellow_greeny) + user_input  + get_color_escape(orange) + "\nAI> " + get_color_escape(yellow) + ai_response + "\n"# + "\n\n" + "".join(history)
        print(clear_screen() + Cursor.POS() + print_string)
        try:
            if re.search("*}:;*", ai_response):
                #print(True)
                break
            else:
                pass
        except Exception as exception:
            print("\n" + get_color_escape(red) + "ERROR CODE: 99\n " + get_color_escape(yellow) + "AI REGEX ERROR: " + get_color_escape(yellow) + str(exception) + RESET)
            #input(get_color_escape(green) + "PRESS ENTER TO PROCEED\n")
    return ai_response
async def main():
    global user_input
    global history
    global ai_response
    global print_string_old
    user_input = input(clear_screen() + Cursor.POS() + get_color_escape(green) + "USER>" + get_color_escape(yellow))
    history.append(";:[USER]:;\n:{" + user_input + "}:\n")
    ai_response = ""
    output = await ai()
    print_string_old = print_string
    try:
        if re.search("*/run(*", ai_response):
            #print(True)
            s=str(re.escape("/run("))

            e=str(re.escape(")"))

            # printing result
            res=re.findall(s+"(.*)"+e,ai_response)[0]

            agree_to_run = input("The AI wants to execute python code. Type Y or Yes to agree and anything else to disagree>")

            if await agree_to_run.lower() == "y" or agree_to_run.lower() == "yes":
                await exec(res)
                input(get_color_escape(green) + "\n\nPRESS ENTER TO PROCEED")
            else:
                pass
        else:
            pass
    except Exception as exception:
        pass
        #print("\n" + get_color_escape(red) + "ERROR CODE: 99\n " + get_color_escape(yellow) + "AI REGEX ERROR: " + get_color_escape(yellow) + str(exception) + RESET)
    #if re.search("*/run py[*", output):
        #for i in output
    history[-1] = (";:[AI]:;\n;:{" + output + "\n")
    #print(output)
    await input()

while True:
    asyncio.run(main())
    #print(output)
    #output = llm(
    #      "<|user|>\nWhat is the purpose of AI?<|end|>\n<|assistant|>", # Prompt
    #      max_tokens=4000, # Generate up to 32 tokens, set to None to generate up to the end of the context window
    #      stop=["<|user|>", "<|assistant|>"], # Stop generating just before the model would generate a new question
    #      echo=True # Echo the prompt back in the output
    #) # Generate a completion, can also call create_completion

    #print(output["choices"][0]["text"])

    #quit()