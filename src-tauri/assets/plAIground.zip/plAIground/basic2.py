def translate_basic_to_python(basic_code):
    python_code = []
    single_indent = "    "
    indent = ""
    
    for line in basic_code.split('\n'):
        line = line.strip()
        
        if line.lstrip().startswith('IF'):
            condition = line[line.find('IF') + 2:line.find('THEN')].strip()
            statement = line[line.find('THEN') + 4:].strip()
            python_code.append(f'{indent}if {condition}:')
            line = f'{single_indent}{statement}'
        
        if line.lstrip().startswith('PRINT'):
            python_code.append(indent + line.replace('PRINT', 'print(') + ')')
        elif line.lstrip().startswith('INPUT'):
            variable = line.split()[1]
            python_code.append(f'{indent}{variable} = input()')
        elif line.lstrip().startswith('FOR'):
            parts = line.split()
            variable = parts[1]
            start = parts[3]
            end = parts[5]
            python_code.append(f'{indent}for {variable} in range({start}, {end} + 1):')
            indent += single_indent
        elif line.lstrip().startswith('NEXT'):
            python_code.append('')
            for single_indent in indent:
                print(single_indent)
        else:
            python_code.append('# ' + line)

    return '\n'.join(python_code)

# Example usage
basic_code = '''
PRINT "Hello, World!"
INPUT X
IF X > 10 THEN PRINT "X is greater than 10"
FOR I = 1 TO 5
    PRINT I
NEXT I
'''

python_code = translate_basic_to_python(basic_code)
print(python_code)
try:
    exec(python_code)
except Exception as exception:
    print(exception)