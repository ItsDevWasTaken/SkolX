document.addEventListener('DOMContentLoaded', function () {
	let mdc_card__outlined =
		document.getElementsByClassName('mdc-card--outlined');
	console.log(mdc_card__outlined);

	for (let element of mdc_card__outlined) {
		console.log(element);
		element.style.border = 'none !important';
	}
});
